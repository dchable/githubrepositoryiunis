package forms.KeyForms;

public class MPredVentKey {
    public static final int ANCHO_VENTANA=600;
    public static final int ALTURA_VENTANA=600;
    public static final int POSX_INI_VENT=200;
    public static final int POSY_INI_VENT=10;


}
