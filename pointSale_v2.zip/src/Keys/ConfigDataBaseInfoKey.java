package Keys;

public class ConfigDataBaseInfoKey{

    public static final String urlDB = "jdbc:postgresql://localhost:";
    public static final String portDB = "5432";
    public static final String userDB = "postgres";
    public static final String passwordDB = "postgres";
    public static final String nameDB = "testPOO";

}
